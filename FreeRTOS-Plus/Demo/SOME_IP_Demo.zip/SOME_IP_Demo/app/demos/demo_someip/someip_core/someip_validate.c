#include "someip_validate.h"

BaseType_t someip_validate_header(const someip_header_t *hdr)
{
    if (!hdr)
        return pdFAIL;

    if (hdr->protocol_version != SOMEIP_PROTOCOL_VERSION)
        return pdFAIL;

    if (hdr->interface_version != SOMEIP_INTERFACE_VERSION)
        return pdFAIL;

    return pdPASS;
}
