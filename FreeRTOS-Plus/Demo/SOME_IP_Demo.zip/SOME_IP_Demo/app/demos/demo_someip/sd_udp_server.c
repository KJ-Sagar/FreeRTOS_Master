#include "FreeRTOS.h"
#include "task.h"
#include "FreeRTOS_Sockets.h"
#include "FreeRTOS_IP.h"

#define SD_UDP_PORT 30490
#define SD_BUF_SIZE 128

static void sd_udp_task(void *arg)
{
    Socket_t sock;
    struct freertos_sockaddr addr, from;
    socklen_t fromlen = sizeof(from);
    uint8_t buf[SD_BUF_SIZE];

    sock = FreeRTOS_socket(
        FREERTOS_AF_INET,
        FREERTOS_SOCK_DGRAM,
        FREERTOS_IPPROTO_UDP
    );

    configASSERT(sock != FREERTOS_INVALID_SOCKET);

    addr.sin_port = FreeRTOS_htons(SD_UDP_PORT);
    FreeRTOS_bind(sock, &addr, sizeof(addr));

    FreeRTOS_printf(("SD: UDP listening on %u\r\n", SD_UDP_PORT));

    for (;;)
    {
        int len = FreeRTOS_recvfrom(
            sock, buf, sizeof(buf), 0, &from, &fromlen
        );

        if (len <= 0)
            continue;

        /* Simple unicast response: list of services */
        uint16_t services[] = {
            FreeRTOS_htons(0x1234),
            FreeRTOS_htons(0x1001),
            FreeRTOS_htons(0x1002)
        };

        FreeRTOS_sendto(
            sock,
            services,
            sizeof(services),
            0,
            &from,
            fromlen
        );
    }
}

void sd_udp_server_start(void)
{
    xTaskCreate(
        sd_udp_task,
        "SD_UDP",
        configMINIMAL_STACK_SIZE * 2,
        NULL,
        tskIDLE_PRIORITY + 1,
        NULL
    );
}
